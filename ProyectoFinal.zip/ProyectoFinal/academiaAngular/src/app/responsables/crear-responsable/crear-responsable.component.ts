import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-responsable',
  templateUrl: './crear-responsable.component.html',
  styleUrls: ['./crear-responsable.component.scss']
})
export class CrearResponsableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
