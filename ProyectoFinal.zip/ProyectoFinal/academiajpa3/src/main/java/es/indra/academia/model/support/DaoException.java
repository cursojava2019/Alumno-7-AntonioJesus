package es.indra.academia.model.support;

public class DaoException extends Exception {

}
