package es.indra.academia.model.support;

public class DatosConexion {

	public static final String URL = "jdbc:postgresql://localhost/concesionario";
	public static final String USUARIO_BD = "postgres";
	public static final String PASSWORD_BD = "JANGULAR";

}
